﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;
using System.Xml.Xsl;
using System.Xml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
namespace mathjax2word
{
    class Program
    {
        static string math = @"<math  xmlns='http://www.w3.org/1998/Math/MathML' display='block'>
                                  <mstyle id='x1-2r1' class='label'/>
                                  <msup>
                                    <mrow>
                                      <mi>a</mi>
                                    </mrow>
                                    <mrow>
                                      <mn>2</mn>
                                    </mrow>
                                  </msup>
                                  <mo class='MathClass-bin'>+</mo>
                                  <msup>
                                    <mrow>
                                      <mi>b</mi>
                                    </mrow>
                                    <mrow>
                                      <mn>2</mn>
                                    </mrow>
                                  </msup>
                                  <mo class='MathClass-rel'>=</mo>
                                  <msup>
                                    <mrow>
                                      <mi>c</mi>
                                    </mrow>
                                    <mrow>
                                      <mn>2</mn>
                                    </mrow>
                                  </msup>
                                </math>";
        static void Main(string[] args)
        {
            //var fileName = @"E:\math.docx";
            //WordOp wordop = new WordOp();
            //try
            //{
            //    wordop.OpenAndActive(fileName, false, false);
            //    var app = wordop.WordApplication;
            //    var doc = wordop.WordDocument;
            //    object unitStory = WdUnits.wdStory;
            //    app.Selection.Move(ref unitStory);
            //    app.Selection.Text = "The result is: ";
            //    app.Selection.Move(ref unitStory);
            //    object fieldType = WdFieldType.wdFieldEmpty;
            //    object preserveFormating = false;
            //    doc.Fields.Add(app.Selection.Range, ref fieldType, @"EQ x=\f(1,y)", ref preserveFormating);
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //finally
            //{
            //    wordop.Close();
            //    Console.WriteLine("关闭文档");
            //}

            //Console.ReadLine();


















            XslCompiledTransform xslTransform = new XslCompiledTransform();

            // The MML2OMML.xsl file is located under 
            // %ProgramFiles%\Microsoft Office\Office12\
            xslTransform.Load("MML2OMML.xsl");

            // Load the file containing your MathML presentation markup.
            using (XmlReader reader = XmlReader.Create(File.Open("mathML.xml", FileMode.Open)))
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    XmlWriterSettings settings = xslTransform.OutputSettings.Clone();

                    // Configure xml writer to omit xml declaration.
                    settings.ConformanceLevel = ConformanceLevel.Fragment;
                    settings.OmitXmlDeclaration = true;

                    XmlWriter xw = XmlWriter.Create(ms, settings);

                    // Transform our MathML to OfficeMathML
                    xslTransform.Transform(reader, xw);
                    ms.Seek(0, SeekOrigin.Begin);

                    StreamReader sr = new StreamReader(ms, Encoding.UTF8);

                    string officeML = sr.ReadToEnd();

                    Console.Out.WriteLine(officeML);

                    // Create a OfficeMath instance from the
                    // OfficeMathML xml.
                    DocumentFormat.OpenXml.Math.OfficeMath om =
                      new DocumentFormat.OpenXml.Math.OfficeMath(officeML);

                    // Add the OfficeMath instance to our 
                    // word template.
                    using (WordprocessingDocument wordDoc =
                      WordprocessingDocument.Open("t1.docx", true))
                    {

                        //DocumentFormat.OpenXml.Wordprocessing.Paragraph par =
                        //  wordDoc.MainDocumentPart.Document.Body.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().FirstOrDefault();


                        foreach (var currentRun in om.Descendants<DocumentFormat.OpenXml.Math.Run>())
                        {
                            // Add font information to every run.
                            DocumentFormat.OpenXml.Wordprocessing.RunProperties runProperties2 =
                              new DocumentFormat.OpenXml.Wordprocessing.RunProperties();

                            RunFonts runFonts2 = new RunFonts() { Ascii = "Cambria Math", HighAnsi = "Cambria Math" };
                            runProperties2.Append(runFonts2);

                            currentRun.InsertAt(runProperties2, 0);
                        }

                        //par.Append(om);






                        var mainPart = wordDoc.MainDocumentPart;

                        /////////////////////////////////////////////////////////////
                        var bookmarks = mainPart.Document.Descendants<BookmarkStart>().ToList();
                        foreach (var mark in bookmarks)
                        {
                            var omclone = (DocumentFormat.OpenXml.Math.OfficeMath)om.Clone();
                            mark.Parent.Append(omclone);
                        }







                    }




                }
            }
            Console.ReadLine();
        }



    }
}
